document.addEventListener("DOMContentLoaded", () => {

  // =======================
  // CONFIGURAÇÕES
  // =======================
  let saldo = parseInt(localStorage.getItem("saldo")) || 1000;
  let aposta = 10;
  let multiplicador = 1;
  let bonus = "normal";
  let girando = false;

  const icons = ["🍒", "🍋", "🍉", "💎", "⭐", "7"];

  // Peso de cada ícone (quanto menor, mais raro)
  const iconPesos = {
    "🍒": 30,
    "🍋": 25,
    "🍉": 20,
    "⭐": 15,
    "💎": 8,
    "7": 2
  };

  // Multiplicador de ganho por ícone
  const iconGanho = {
    "🍒": 2,
    "🍋": 3,
    "🍉": 4,
    "⭐": 5,
    "💎": 10,
    "7": 20
  };

  // =======================
  // ELEMENTOS
  // =======================
  const slots = document.querySelectorAll(".slot");
  const saldoEl = document.getElementById("saldo");
  const girarBtn = document.getElementById("girar");
  const mensagemEl = document.getElementById("mensagem");
  const valorApostaEl = document.getElementById("valorAposta");
  const possivelGanhoEl = document.getElementById("possivelGanho");
  const btnAumentar = document.getElementById("aumentarAposta");
  const btnDiminuir = document.getElementById("diminuirAposta");

  // =======================
  // SONS
  // =======================
  const winSound = new Audio("../sounds/win.mp3");
  const loseSound = new Audio("../sounds/lose.mp3");
  const spinSound = new Audio("../sounds/spin.mp3");
  const cashSound = new Audio("../sounds/cash.mp3");

  spinSound.loop = true;
  spinSound.volume = 0.4;
  winSound.volume = 0.3;
  loseSound.volume = 0.2;
  cashSound.volume = 0.5;

  // =======================
  // SORTEIO COM PESO
  // =======================
  function sortearIcone() {
    const total = Object.values(iconPesos).reduce((a, b) => a + b, 0);
    let rand = Math.random() * total;
    for (const [icon, peso] of Object.entries(iconPesos)) {
      rand -= peso;
      if (rand <= 0) return icon;
    }
    return icons[0];
  }

  // =======================
  // FUNÇÕES BASE
  // =======================
  function atualizarSaldo() {
    saldoEl.innerText = saldo.toLocaleString("pt-BR");
    localStorage.setItem("saldo", saldo);
    verificarSaldoMinimo();
  }

  function verificarSaldoMinimo() {
    if (saldo < aposta) {
      girarBtn.disabled = true;
      girarBtn.textContent = "SEM SALDO";
    } else {
      girarBtn.disabled = false;
      girarBtn.textContent = "🎰 GIRAR";
    }
  }

  function atualizarAposta() {
    valorApostaEl.innerText = aposta;
    calcularPossivelGanho();
    verificarSaldoMinimo();
  }

  // =======================
  // MULTIPLICADOR TOTAL
  // bonus: normal=1x | lucky=1.5x | risk=3x (alto risco) | double=2x ganho dobrado
  // =======================
  function getMultiplicadorTotal() {
    let bonusMultiplicador = 1;
    if (bonus === "lucky")  bonusMultiplicador = 1.5;
    if (bonus === "risk")   bonusMultiplicador = 3;
    if (bonus === "double") bonusMultiplicador = 2;
    return multiplicador * bonusMultiplicador;
  }

  function calcularPossivelGanho() {
    // Possível ganho baseado no ícone mais comum (cereja = 2x)
    let ganho = aposta * 2 * getMultiplicadorTotal();
    possivelGanhoEl.innerText = "💰 Possível ganho mín: " + ganho.toLocaleString("pt-BR");
  }

  // =======================
  // CONTROLE DE APOSTA
  // =======================
  const apostaMin = 5;
  const apostaMax = 500;

  btnAumentar.addEventListener("click", () => {
    if (girando) return;
    if (aposta + 5 <= apostaMax && aposta + 5 <= saldo) {
      aposta += 5;
      atualizarAposta();
    }
  });

  btnDiminuir.addEventListener("click", () => {
    if (girando) return;
    if (aposta - 5 >= apostaMin) {
      aposta -= 5;
      atualizarAposta();
    }
  });

  // =======================
  // BONUS E MULTIPLICADOR
  // =======================
  window.setBonus = function(tipo) {
    bonus = tipo;
    calcularPossivelGanho();

    // Fecha o painel após escolher
    document.getElementById("bonusPanel").classList.remove("active");

    // Feedback visual no botão de bonus
    mensagemEl.style.color = "#fbbf24";
    const labels = { normal: "Modo Normal", lucky: "Lucky 🍀 ativado!", risk: "Risk 🔥 ativado!", double: "Double Win 💥 ativado!" };
    mensagemEl.innerText = labels[tipo] || "";
    setTimeout(() => { mensagemEl.innerText = "Boa sorte! 🍀"; mensagemEl.style.color = ""; }, 2000);
  };

  window.setMultiplicador = function(valor) {
    multiplicador = valor;
    calcularPossivelGanho();

    // Fecha o painel após escolher
    document.getElementById("valorPanel").classList.remove("active");

    mensagemEl.style.color = "#fbbf24";
    mensagemEl.innerText = `Multiplicador ${valor}x ativado!`;
    setTimeout(() => { mensagemEl.innerText = "Boa sorte! 🍀"; mensagemEl.style.color = ""; }, 2000);
  };

  // =======================
  // ANIMAÇÃO DE SALDO
  // =======================
  function animarGanho(start, end) {
    const duration = 1000;
    const steps = 30;
    const increment = (end - start) / steps;
    const stepTime = duration / steps;
    let current = start;

    const interval = setInterval(() => {
      current += increment;
      if (current >= end) {
        current = end;
        clearInterval(interval);
      }
      saldoEl.innerText = Math.floor(current).toLocaleString("pt-BR");
    }, stepTime);
  }

  // =======================
  // GIRAR
  // =======================
  function girar() {
    if (girando || saldo < aposta) return;

    girando = true;
    saldo -= aposta;
    atualizarSaldo();
    girarBtn.disabled = true;
    mensagemEl.innerText = "🎰 Girando...";
    mensagemEl.style.color = "";

    // Remove classes visuais anteriores
    slots.forEach(s => {
      s.classList.remove("jackpot", "quase", "perdeu");
      s.style.borderColor = "";
    });

    spinSound.currentTime = 0;
    spinSound.play();

    const resultados = [];

    // Cada slot para em tempos diferentes (cascata)
    function animarSlot(slotIndex, duracao, callback) {
      const slot = slots[slotIndex];
      const intervalo = setInterval(() => {
        slot.innerText = icons[Math.floor(Math.random() * icons.length)];
      }, 80);

      setTimeout(() => {
        clearInterval(intervalo);
        const resultado = sortearIcone();
        slot.innerText = resultado;
        resultados[slotIndex] = resultado;

        // Pequena animação de "encaixe"
        slot.style.transform = "scale(1.15)";
        setTimeout(() => { slot.style.transform = ""; }, 150);

        if (callback) callback();
      }, duracao);
    }

    // Para em cascata: 1s, 2s, 3s
    animarSlot(0, 1000, () => {
      animarSlot(1, 1500, () => {
        animarSlot(2, 1500, () => {
          spinSound.pause();
          spinSound.currentTime = 0;
          verificarResultadoFinal(resultados);
          girando = false;
          if (saldo >= aposta) {
            girarBtn.disabled = false;
            girarBtn.textContent = "🎰 GIRAR";
          } else {
            girarBtn.textContent = "SEM SALDO";
          }
        });
      });
    });
  }

  // =======================
  // RESULTADO FINAL
  // =======================
  function verificarResultadoFinal(resultados) {
    const [a, b, c] = resultados;
    const tresIguais = a === b && b === c;
    const doisIguais = (a === b && a !== c) || (b === c && b !== a) || (a === c && a !== b);

    if (tresIguais) {
      // JACKPOT
      const multiplicadorIcone = iconGanho[a] || 2;
      const ganho = Math.floor(aposta * multiplicadorIcone * getMultiplicadorTotal());
      const saldoAntigo = saldo;
      saldo += ganho;
      localStorage.setItem("saldo", saldo);

      animarGanho(saldoAntigo, saldo);

      // Feedback visual nos slots
      slots.forEach(s => s.classList.add("jackpot"));

      // Mensagem baseada no ícone
      const isMega = a === "7" || a === "💎";
      mensagemEl.style.color = "#fbbf24";

      if (isMega) {
        mensagemEl.innerText = `💥 MEGA JACKPOT! +${ganho.toLocaleString("pt-BR")} 💥`;
        cashSound.play();
      } else {
        mensagemEl.innerText = `🔥 JACKPOT! +${ganho.toLocaleString("pt-BR")} 🔥`;
        winSound.play();
      }

      // Remove efeito após 2s
      setTimeout(() => {
        slots.forEach(s => s.classList.remove("jackpot"));
        mensagemEl.innerText = "Boa sorte! 🍀";
        mensagemEl.style.color = "";
      }, 2500);

    } else if (doisIguais) {
      // QUASE — 2 iguais, pequeno prêmio de consolação
      const ganhoConsolacao = Math.floor(aposta * 0.5);
      saldo += ganhoConsolacao;
      atualizarSaldo();

      slots.forEach(s => s.style.borderColor = "rgba(255,165,0,0.6)");
      mensagemEl.style.color = "orange";
      mensagemEl.innerText = `😮 Quase! +${ganhoConsolacao} de consolação`;

      setTimeout(() => {
        slots.forEach(s => s.style.borderColor = "");
        mensagemEl.innerText = "Boa sorte! 🍀";
        mensagemEl.style.color = "";
      }, 2000);

      loseSound.play();

    } else {
      // PERDEU
      slots.forEach(s => s.style.borderColor = "rgba(255,50,50,0.4)");
      mensagemEl.style.color = "#ef4444";
      mensagemEl.innerText = "😔 Você perdeu...";

      setTimeout(() => {
        slots.forEach(s => s.style.borderColor = "");
        mensagemEl.innerText = "Boa sorte! 🍀";
        mensagemEl.style.color = "";
      }, 2000);

      loseSound.play();
    }
  }

  // =======================
  // EVENTOS
  // =======================
  girarBtn.addEventListener("click", girar);

  // =======================
  // INIT
  // =======================
  atualizarSaldo();
  atualizarAposta();
  calcularPossivelGanho();

});