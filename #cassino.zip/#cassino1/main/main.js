// ================= SALDO =================
if (!localStorage.getItem("saldo")) {
  localStorage.setItem("saldo", 10000);
}

const saldoEl = document.getElementById("saldoLobby");
if (saldoEl) {
  saldoEl.innerText = localStorage.getItem("saldo");
}

// ================= NAVEGAÇÃO =================
document.querySelector(".slot")?.addEventListener("click", () => {
  window.location.href = "slot/slot.html";
});

document.querySelector(".roulette")?.addEventListener("click", () => {
  window.location.href = "roulette/roulette.html";
});

document.querySelector(".blackjack")?.addEventListener("click", () => {
  window.location.href = "blackjack/blackJ.html";
});

// ================= SOM =================
const hoverSound = new Audio("../sounds/hover.mp3");
hoverSound.volume = 0.1;

document.querySelectorAll(".jogo-card").forEach(card => {
  card.addEventListener("mouseenter", () => {
    hoverSound.currentTime = 0;
    hoverSound.play().catch(() => {});
  });
});