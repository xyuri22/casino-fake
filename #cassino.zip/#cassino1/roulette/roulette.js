
// ==== ESC ====
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && historyPanel?.classList.contains("open")) {
    historyPanel.classList.remove("open");

    // libera scroll de volta
    document.body.style.overflow = "auto";
  }
});

// ==== HISTORICO ====
const historyBtn = document.getElementById("historyBtn");
const historyPanel = document.getElementById("historyPanel");
const historyList = document.getElementById("historyList");

let history = JSON.parse(localStorage.getItem("history")) || [];

if (historyBtn && historyPanel) {
  historyBtn.addEventListener("click", () => {
    historyPanel.classList.toggle("open");


    // 🔥 trava/destrava scroll do fundo
    document.body.style.overflow =
      historyPanel.classList.contains("open") ? "hidden" : "auto";
  });
}

// ==== OUTROS ====
const track = document.getElementById("track");
const spinBtn = document.getElementById("spinBtn");
const betAmountInput = document.getElementById("betAmount");
const balanceDisplay = document.getElementById("balance");
const resultMessage = document.getElementById("resultMessage");
const colorOptions = document.querySelectorAll(".color-option");

const autoPanel = document.getElementById("autoPanel");
const autoOptions = document.querySelectorAll("#autoPanel button");
const autoStatus = document.getElementById("autoStatus");
const autoBtn = document.getElementById("autoBtn");

if (autoBtn && autoPanel) {
  autoBtn.addEventListener("click", () => {

    // 👉 SE JÁ ESTÁ RODANDO → vira botão PARAR
    if (autoRunning) {
      autoStopRequested = true;
      autoBtn.textContent = "AUTO";
      return;
    }

    // 👉 SE NÃO ESTÁ → abre painel normal
    autoPanel.classList.toggle("open");
  });
}

autoOptions.forEach(btn => {
  btn.addEventListener("click", () => {
    if (spinning) return;

    autoRunning = false;

    setTimeout(() => {
      autoTotal = parseInt(btn.dataset.spins);
      autoLeft = autoTotal;
      autoCount = 0;
      autoRunning = true;
      autoStopRequested = false;

      autoBtn.textContent = "PARAR"; // 👈 MUDA TEXTO
      autoPanel.classList.remove("open");

      runAutoSpin();
    }, 50);
  });
});

let autoCount = 0;

function runAutoSpin() {

  if (!autoRunning) return;

    if (autoStopRequested) 
    autoRunning = false;

  if (autoLeft <= 0) {
    autoRunning = false;

     autoBtn.textContent = "AUTO"; 

    setTimeout(() => {
      autoStatus.style.opacity = "0";
    }, 1500);

    return;
  }

  if (spinning) {
    setTimeout(runAutoSpin, 300);
    return;
  }

  autoCount++;
  autoLeft--;

  autoStatus.textContent = `${autoCount}/${autoTotal} (faltam ${autoLeft})`;
  autoStatus.style.opacity = "1";

  spin();

  setTimeout(runAutoSpin, spinDuration + 600);
}

// ===== SALDO =====
let saldo = parseInt(localStorage.getItem("saldo")) || 1000;

// ===== ESTADO =====
let selectedColor = null;
let spinning = false;
let winStreak = 0;
let loseStreak = 0;
const spinDuration = 7000;
let balanceAnimating = false;
let autoRunning = false;
let autoTotal = 0;     // total escolhido
let autoLeft = 0;      // restantes
let autoStopRequested = false;

// ===== SOM =====
const winSound = new Audio("../sounds/win.mp3");
const loseSound = new Audio("../sounds/lose.mp3");
const spinSound = new Audio("../sounds/spin.mp3");

const baseSpinVolume = 0.5;

spinSound.loop = true;
winSound.volume = 0.2;
loseSound.volume = 0.2;

// ===== SALDO =====
function saveSaldo() {
  localStorage.setItem("saldo", saldo);
  updateSaldoDisplay();
}

function updateSaldoDisplay() {
  if (balanceDisplay) {
    balanceDisplay.textContent = `Saldo: ${saldo}`;
  }
}



// ==== ANIMAÇÃO DO SALDO ====

  function animateBalance(start, end) {
  if (!balanceDisplay || balanceAnimating) return;

  balanceAnimating = true;

  let current = start;
  const duration = 1200;
  const steps = 30;
  const increment = (end - start) / steps;
  const stepTime = duration / steps;

  const interval = setInterval(() => {
    current += increment;

    if (current >= end) {
      current = end;
      clearInterval(interval);
      balanceAnimating = false;
    }

    balanceDisplay.textContent = `Saldo: ${Math.floor(current)}`;
  }, stepTime);
}
// ==== HISTORICO =====

function addToHistory(entry) {
  history.unshift(entry);

  if (history.length > 50) {
    history.pop();
  }

  localStorage.setItem("history", JSON.stringify(history));
  renderHistory();
}

function renderHistory() {
  if (!historyList) return;

  historyList.innerHTML = "";

  history.forEach(item => {
    const div = document.createElement("div");
    div.classList.add("history-item");

    div.innerHTML = `
      <div>🎯 Caiu: <b>${item.result}</b></div>
      <div>🎨 Escolheu: <b>${item.selected}</b></div>
      <div>💰 Apostou: ${item.bet}</div>
      <div class="${item.win ? "history-win" : "history-lose"}">
        ${item.win ? "Ganhou" : "Perdeu"}: ${item.amount > 0 ? "+" : ""}${item.amount}
      </div>
    `;

    historyList.appendChild(div);
  });
}

// ===== MENSAGEM =====
function showMessage(text, win = false) {
  if (!resultMessage) return;

  resultMessage.textContent = text;
  resultMessage.style.color = win ? "lime" : "red";
  resultMessage.style.opacity = "1";

  setTimeout(() => {
    resultMessage.style.opacity = "0";
  }, 3000);
}

// ==== ANIMAÇÃO DE GANHO ====

function animateWin(amount) {
  if (!resultMessage) return;

  let current = 0;
  const duration = 1200;
  const steps = 30;
  const increment = amount / steps;
  const stepTime = duration / steps;

  resultMessage.style.color = "lime";
  resultMessage.style.opacity = "1";

  resultMessage.classList.add("win-effect");

  const interval = setInterval(() => {
    current += increment;

    if (current >= amount) {
      current = amount;
      clearInterval(interval);

      setTimeout(() => {
        resultMessage.style.opacity = "0";
        resultMessage.classList.remove("win-effect");
      }, 1000);
    }

    resultMessage.textContent = `GANHO +${Math.floor(current)}`;
  }, stepTime);
}
// ===== NEAR MISS ====
function checkNearMiss(blocks, targetIndex, result) {
  if (result === "white") return false;

  const prev = blocks[targetIndex - 1];
  const next = blocks[targetIndex + 1];

  if (
    prev?.classList.contains("white") ||
    next?.classList.contains("white")
  ) {
    return true;
  }

  return false;
}

// ==== NEAR MISS HG ====
function highlightNearMiss(blocks, targetIndex) {
  const prev = blocks[targetIndex - 1];
  const next = blocks[targetIndex + 1];

  if (prev?.classList.contains("white")) {
    prev.classList.add("near-miss");

    setTimeout(() => {
      prev.classList.remove("near-miss");
    }, 1500);
  }

  if (next?.classList.contains("white")) {
    next.classList.add("near-miss");

    setTimeout(() => {
      next.classList.remove("near-miss");
    }, 1500);
  }
}
function triggerShake() {
  document.body.classList.add("shake");

  setTimeout(() => {
    document.body.classList.remove("shake");
  }, 400);
}
// ==== SCREEN SHAKE ====
function triggerStrongShake() {
  document.body.classList.add("shake-strong");

  setTimeout(() => {
    document.body.classList.remove("shake-strong");
  }, 600);
}
// ==== BIG WIN ====
function triggerBigWin(amount) {
  const bigWinDiv = document.createElement("div");
  bigWinDiv.classList.add("big-win");

  bigWinDiv.textContent = `💥 BIG WIN +${amount} 💥`;

  document.body.appendChild(bigWinDiv);

  setTimeout(() => {
    bigWinDiv.remove();
  }, 2000);
}

// ===== SELEÇÃO DE COR =====
colorOptions.forEach(option => {
  option.addEventListener("click", () => {
    if (spinning) return;

    colorOptions.forEach(o => o.classList.remove("selected"));
    option.classList.add("selected");
    selectedColor = option.dataset.color;
  });
});

// ===== GERAR ROLETA =====
function generateBlocks(amount = 120) {
  if (!track) return;

  track.innerHTML = "";

  for (let i = 0; i < amount; i++) {
    let color = i % 2 === 0 ? "red" : "black";
    if (Math.random() < 0.08) color = "white";

    const block = document.createElement("div");
    block.classList.add("block", color);
    track.appendChild(block);
  }
}

// ===== RESULTADO =====
function getResult() {
  const rand = Math.random() * 100;

  if (rand < 46) return "red";
  if (rand < 92) return "black";
  return "white";
}

// ==== WHITEPOT ====
function triggerWhiteEffect(amount) {
  const flash = document.createElement("div");
  flash.classList.add("white-flash");

  flash.textContent = `⚪ JACKPOT +${amount} ⚪`;

  document.body.appendChild(flash);

  setTimeout(() => {
    flash.remove();
  }, 2000);
}
// ==== STREAK ====
function updateStreakDisplay() {
  if (!resultMessage) return;

  if (winStreak >= 3) {
    resultMessage.textContent += "🔥";
  }

  if (loseStreak >= 3) {
    resultMessage.textContent += "🥶";
  }
}


// ===== SPIN =====
function spin() {
  if (!track || !spinBtn) return;
  if (spinning) return;

  if (!selectedColor) {
    showMessage("Escolha uma cor!", false);
    return;
  }

  const betAmount = parseInt(betAmountInput.value);

  if (!betAmount || betAmount <= 0 || betAmount > saldo) {
    showMessage("Aposta inválida!", false);
    return;
  }

  spinning = true;
  spinBtn.disabled = true;

  colorOptions.forEach(o => {
    o.style.pointerEvents = "none";
    o.classList.add("disabled");
   
  });

  // desconta aposta
  saldo -= betAmount;
  saveSaldo();

  // reset visual
  track.style.transition = "none";
  track.style.transform = "translateY(0px)";
  void track.offsetHeight;

  generateBlocks();

  const result = getResult();
  const blocks = document.querySelectorAll(".block");

  if (!blocks.length) {
    spinning = false;
    spinBtn.disabled = false;
    return;
  }

  // ===== TARGET GARANTIDO =====
  let targetIndex = -1;

  for (let i = 80; i < blocks.length; i++) {
    if (blocks[i]?.classList.contains(result)) {
      targetIndex = i;
      break;
    }
  }

  // fallback seguro (nunca quebra)
  if (targetIndex === -1) {
    targetIndex = Math.floor(blocks.length / 2);
  }

  // ===== DISTÂNCIA =====
  let distance = 0;

  for (let i = 0; i < targetIndex; i++) {
  distance += blocks[i].clientHeight;
}

  const container = document.querySelector(".roulette-container");
  const pointer = document.querySelector(".pointer");

  if (!container || !pointer || !blocks[targetIndex]) {
    spinning = false;
    spinBtn.disabled = false;
    return;
  }

  const pointerPos = container.clientHeight / 2;
  distance -= (pointerPos - 35);

  // ===== SOM =====
  spinSound.pause();
  spinSound.currentTime = 0;
  spinSound.volume = baseSpinVolume;
  spinSound.play();

  setTimeout(() => {
    spinSound.volume = 0.2;
  }, spinDuration - 1500);

  // ===== ANIMAÇÃO =====
  track.style.transition = `transform ${spinDuration}ms cubic-bezier(0.08,0.7,0.1,1)`;
  track.style.transform = `translateY(-${distance}px)`;

  // ===== FINAL =====
  setTimeout(() => {
    const winnerBlock = blocks[targetIndex];

    winnerBlock?.classList.add("winner");
    pointer.classList.add("hit");

    setTimeout(() => {
      winnerBlock?.classList.remove("winner");
      pointer.classList.remove("hit");
    }, 1000);

    spinSound.pause();
    spinSound.currentTime = 0;

    const win = selectedColor === result;
    const nearMiss = checkNearMiss(blocks, targetIndex, result);
    if (win) {
  winStreak++;
  loseStreak = 0;
} else {
  loseStreak++;
  winStreak = 0;
}
    const multiplier = result === "white" ? 14 : 2;

    if (win) {
  const winAmount = betAmount * multiplier;
  const oldSaldo = saldo;
  const newSaldo = saldo + winAmount;

  animateBalance(oldSaldo, newSaldo);

  saldo = newSaldo;
  localStorage.setItem("saldo", saldo);

  winSound.currentTime = 0;
  winSound.play();

  animateWin(winAmount);

   if (result === "white") {
  triggerWhiteEffect(winAmount);
  triggerStrongShake();
}

} else {
  loseSound.currentTime = 0;
  loseSound.play();

  if (nearMiss) {
  showMessage("QUASE!!! ⚪😱", false);
  highlightNearMiss(blocks, targetIndex);
  triggerShake();
  } else {
    showMessage("Você perdeu!", false);
  }
}

// ✅ AQUI FORA DO IF (IMPORTANTE)
updateStreakDisplay();

    // libera UI
    colorOptions.forEach(o => {
      o.style.pointerEvents = "auto";
      o.classList.remove("disabled");
    });

    spinBtn.disabled = false;
    spinning = false;

    addToHistory({
  result: result,
  selected: selectedColor,
  bet: betAmount,
  amount: win ? (betAmount * multiplier) : -betAmount,
  win: win
});

  }, spinDuration);
}

// ===== INIT =====
spinBtn.addEventListener("click", spin);

updateSaldoDisplay();
generateBlocks();
renderHistory();
document.addEventListener("DOMContentLoaded", () => {
  });
