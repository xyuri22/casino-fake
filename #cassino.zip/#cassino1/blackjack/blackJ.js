let BJgame = {
    'you': {'scoreSpan': '#yourscore' , 'div': '#your-box', 'score': 0},
    'dealer': {'scoreSpan': '#dealerscore' , 'div': '#dealer-box', 'score': 0},
    
    'cards': ['2C','3C','4C','5C','6C','7C','8C','9C','10C','KC','QC','JC','AC','2D','3D','4D','5D','6D','7D','8D','9D','10D','KD','QD','JD','AD','2H','3H','4H','5H','6H','7H','8H','9H','10H','KH','QH','JH','AH','2S','3S','4S','5S','6S','7S','8S','9S','10S','KS','QS','JS','AS'],
    
    'cardsmap': {'2C':2,'3C':3,'4C':4,'5C':5,'6C':6,'7C':7,'8C':8,'9C':9,'10C':10,'KC':10,'QC':10,'JC':10,'AC':[1, 11],'2D':2,'3D':3,'4D':4,'5D':5,'6D':6,'7D':7,'8D':8,'9D':9,'10D':10,'KD':10,'QD':10,'JD':10,'AD':[1, 11],'2H':2,'3H':3,'4H':4,'5H':5,'6H':6,'7H':7,'8H':8,'9H':9,'10H':10,'KH':10,'QH':10,'JH':10,'AH':[1, 11],'2S':2,'3S':3,'4S':4,'5S':5,'6S':6,'7S':7,'8S':8,'9S':9,'10S':10,'KS':10,'QS':10,'JS':10,'AS':[1, 11]},

    'wins':0,
    'losses':0,
    'draws':0
};

let betMode = "normal";

let saldo = parseInt(localStorage.getItem("saldo")) || 10000;
let currentBet = 0;
let roundStarted = false;


const saldoEl = document.getElementById("saldo");
const betEl = document.getElementById("bet");

updateMoneyUI();

function updateMoneyUI() {
    saldoEl.textContent = saldo;
    betEl.textContent = currentBet;

    localStorage.setItem("saldo", saldo);
}
function startRound(){

    if(roundStarted) return;

    let input = document.getElementById("betAmount");

    let value = parseInt(input.value);

    if(!value || value <= 0){
        alert("Digite uma aposta válida!");
        return;
    }

    if(value > saldo){
        alert("Saldo insuficiente!");
        return;
    }
betEl.textContent = currentBet;
    currentBet = value;

    saldo -= currentBet;

    roundStarted = true;

    updateMoneyUI();

    document.querySelector('#command').textContent = "Rodada iniciada!";
}
function addBet(amount){

    if(roundStarted) return;

    if(saldo >= amount){    
        currentBet += amount;
        updateMoneyUI();
    }
}

function clearBet(){

    if(roundStarted) return;

    saldo += currentBet;
    currentBet = 0;

    updateMoneyUI();
}

function maxBet(){

    if(roundStarted) return;

    currentBet += saldo;
    saldo = 0;

    updateMoneyUI();
}

const You = BJgame['you'];
const Dealer = BJgame['dealer'];

const tink = new Audio('../sounds/tink.wav');

function drawCard(activeplayer) {
    const randomNumber = Math.floor(Math.random() * (BJgame['cards'].length));
    const currentCard = BJgame['cards'].splice(randomNumber, 1)[0];
    let card = document.createElement('img');
    card.src = `./static/${currentCard}.png`;
    document.querySelector(activeplayer['div']).appendChild(card);
    const hitsound = new Audio('../sounds/swish.m4a');
    hitsound.play();

    updateScore(currentCard, activeplayer);

    showScore(activeplayer);    
}

function updateScore(currentcard, activeplayer){
    // For Ace
    if(currentcard == 'AC' || currentcard == 'AD' || currentcard == 'AH' || currentcard == 'AS'){
        if((activeplayer['score'] + BJgame['cardsmap'][currentcard][1]) <= 21){

            activeplayer['score'] += BJgame['cardsmap'][currentcard][1];
        }
        else{
            activeplayer['score'] += BJgame['cardsmap'][currentcard][0];
        }
    }
    else{  //For Other Cases
        activeplayer['score'] += BJgame['cardsmap'][currentcard];
    }   
}

function showScore(activeplayer){
    if(activeplayer['score']>21){
        document.querySelector(activeplayer['scoreSpan']).textContent = 'BUST!';
        document.querySelector(activeplayer['scoreSpan']).style.color = 'yellow';
    }
    else{
        document.querySelector(activeplayer['scoreSpan']).textContent = activeplayer['score'];
    }
}

// Compute Winner Function
function findwinner(){
    let winner;

    if(You['score']<=21){
        if(Dealer['score']<You['score'] || Dealer['score']>21){
            BJgame['wins']++;
            winner = You;
        }
        else if(Dealer['score'] == You['score']){
            BJgame['draws']++;
        }
        else{
            BJgame['losses']++;
            winner = Dealer;
        }
    }
    else if(You['score']>21 && Dealer['score']<=21){
        BJgame['losses']++;
        winner = Dealer;
    }
    else if(You['score']>21 && Dealer['score']>21){
        BJgame['draws']++;
    }
    return winner;
}

// Results
const winSound = new Audio('../sounds/cash.mp3'); 
const cheers = new Audio('../sounds/cheer.wav');
const loseSound = new Audio('../sounds/aww.mp3');
const drawSound = new Audio('../sounds/ohh.mp3');

function showresults(winner){
    let payoutMultiplier = 2;

    // Bloqueia stand/hit durante a exibição do resultado
    roundStarted = false;

    if(winner == You){
        let reward = currentBet * payoutMultiplier;
        saldo += reward;
        updateMoneyUI();
        document.querySelector('#command').textContent = "Você Ganhou! 🎉";
        document.querySelector('#command').style.color = 'lime';
        winSound.play();
        cheers.play();
        cheers.volume = 0.4;
        setTimeout(() => { BJdeal(); }, 2000);
    }
    else if(winner == Dealer){
        document.querySelector('#command').textContent = "Você Perdeu!";
        document.querySelector('#command').style.color = 'red';
        loseSound.play();
        setTimeout(() => { BJdeal(); }, 2000);
    }
    else{
        // Empate: devolve a aposta
        saldo += currentBet;
        updateMoneyUI();
        document.querySelector('#command').textContent = 'Empate! Aposta devolvida.';
        document.querySelector('#command').style.color = 'orange';
        drawSound.play();
        setTimeout(() => { BJdeal(); }, 2000);
    }
}

// Scoreboard
function scoreboard(){
    document.querySelector('#wins').textContent = BJgame['wins'];
    document.querySelector('#losses').textContent = BJgame['losses'];
    document.querySelector('#draws').textContent = BJgame['draws'];
}

// Hit Button (starting)
document.querySelector('#hit').addEventListener('click', BJhit);

const hitsound = new Audio('../sounds/swish.m4a');

function BJhit(){

    if(!roundStarted || standLocked){
        if(!roundStarted) alert("Clique em JOGAR primeiro!");
        return;
    }

    if(You['score'] <= 21){
        drawCard(You);
        // Se estourou, dealer ainda joga para checar bust duplo
        if(You['score'] > 21){
            standLocked = true;
            roundStarted = false;
            while(Dealer['score'] < 16){
                drawCard(Dealer);
            }
            setTimeout(function(){
                showresults(findwinner());
                scoreboard();
                standLocked = false;
            }, 600);
        }
    }
}

// Deal Button
document.querySelector('#deal').addEventListener('click', BJdeal);

function BJdeal(){
    // Remove cartas do jogador
    document.querySelector('#your-box').querySelectorAll('img').forEach(img => img.remove());
    // Remove cartas do dealer
    document.querySelector('#dealer-box').querySelectorAll('img').forEach(img => img.remove());

    // Reset estado (mantém o valor da aposta no input)
    roundStarted = false;
    standLocked = false;
    currentBet = 0;

    updateMoneyUI();

    // Reembaralha
    BJgame['cards'] = ['2C','3C','4C','5C','6C','7C','8C','9C','10C','KC','QC','JC','AC','2D','3D','4D','5D','6D','7D','8D','9D','10D','KD','QD','JD','AD','2H','3H','4H','5H','6H','7H','8H','9H','10H','KH','QH','JH','AH','2S','3S','4S','5S','6S','7S','8S','9S','10S','KS','QS','JS','AS'];

    // Zera pontuações
    You['score'] = 0;
    document.querySelector(You['scoreSpan']).textContent = 0;
    document.querySelector(You['scoreSpan']).style.color = 'whitesmoke';
    Dealer['score'] = 0;
    document.querySelector(Dealer['scoreSpan']).textContent = 0;
    document.querySelector(Dealer['scoreSpan']).style.color = 'whitesmoke';

    // Se tinha uma aposta anterior, já inicia a rodada automaticamente
    const input = document.getElementById("betAmount");
    const lastBet = parseInt(input.value);
    if(lastBet && lastBet > 0 && lastBet <= saldo){
        setTimeout(() => { startRound(); }, 100);
    } else {
        document.querySelector('#command').textContent = "Aposte";
        document.querySelector('#command').style.color = 'white';
    }
}

// Dealer's Logic (2nd player) OR Stand button
document.querySelector('#stand').addEventListener('click', BJstand)

let standLocked = false;

function BJstand(){
    if(!roundStarted){
        alert("Clique em JOGAR primeiro!")
        return;
    }
    if(standLocked) return;
    if(You['score']===0){
        alert("Compre cartas primeiro!")
        return;
    }

    standLocked = true;
    roundStarted = false; // impede hit durante o stand

    while(Dealer['score']<16){
        drawCard(Dealer);
    }
    setTimeout(function(){
        showresults(findwinner());
        scoreboard();
        standLocked = false;
    }, 800); 
}